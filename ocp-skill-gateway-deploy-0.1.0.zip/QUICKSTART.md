# OCP Skill Gateway 部署包 — QUICKSTART

> 把 OCP 注册中心(`ocp.deeplumen.io/mcp`)的 catalog 能力暴露成 LLM Agent 平台
> (Coze / 元器 / 百炼 / ChatGPT Actions)能识别的 HTTP OpenAPI 插件。

## 30 秒部署

```bash
# 解压后在解压目录里跑(目录里就是这个 QUICKSTART.md 旁边):
docker build \
  -f apps/examples/ocp-skill-gateway/Dockerfile \
  -t ocp-skill-gateway:0.1.0 \
  .

docker run -d --name skill-gateway \
  -p 4330:4330 \
  -e SKILL_GATEWAY_API_KEYS=sk_prod_xxx \
  -e SKILL_GATEWAY_PUBLIC_BASE_URL=https://skill-gateway.deeplumen.io \
  ocp-skill-gateway:0.1.0

curl http://localhost:4330/health
# {"ok":true,"upstream":"ocp_mcp","upstream_url":"https://ocp.deeplumen.io/mcp",...}
```

## 包内是什么

```
.
├── .dockerignore                       # docker build 用,默认全排除 + 白名单
├── QUICKSTART.md                       # 你正在看的这个文件
└── apps/examples/ocp-skill-gateway/
    ├── Dockerfile                      # 多阶段:bun build → alpine runtime
    ├── docker-compose.yml              # 一键起 + healthcheck
    ├── README.md                       # 项目介绍
    ├── package.json                    # bun 包配置(运行时用)
    ├── src/                            # TypeScript 源码
    └── docs/
        ├── 部署给运维.md                ★ 主参考:env / nginx / 故障排查
        ├── OCP MCP 上游接入手记.md       上游怎么接的设计文档
        ├── Coze上架手记.md              Coze 端怎么挂插件的实操记录
        └── 技术实现路径.md              整体技术路径
```

## 主参考文档

- **`apps/examples/ocp-skill-gateway/docs/部署给运维.md`** — 必填 env、健康检查、反代示例、故障排查
- 想理解上游是什么 → `OCP MCP 上游接入手记.md`
- 想知道 LLM 平台怎么接 → `Coze上架手记.md`

## 必填 env 速查

| 变量 | 必填 | 示例 |
|---|---|---|
| `SKILL_GATEWAY_API_KEYS` | ✅ | `sk_prod_a,sk_prod_b`(给 LLM 平台用的 X-Skill-Key,逗号分隔) |
| `SKILL_GATEWAY_PUBLIC_BASE_URL` | ✅ | `https://skill-gateway.deeplumen.io`(写进 OpenAPI 的 `servers.url`) |

其余 env 都有合理默认,详见 `docs/部署给运维.md`。

## 出网依赖

唯一一个:**`https://ocp.deeplumen.io/mcp`**(OCP 注册中心 MCP server)。
无数据库,无 Redis,无其它第三方账号(alimama / 京东 等都在注册中心后端封装好了)。
